﻿function dataAttachment() {
    return {
        searchkeyword: $("#SearchAttachmentKeyword").val(),
        id_nds: dataItem.id_nds
    };
}