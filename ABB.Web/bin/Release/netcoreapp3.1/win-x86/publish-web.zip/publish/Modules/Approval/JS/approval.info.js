﻿function dataApprovalInfo() {
    return {
        searchkeyword: $("#SearchApprovalInfoKeyword").val(),
        kd_cb: dataItem.kd_cb,
        kd_product: dataItem.kd_product,
        kd_thn: dataItem.kd_thn,
        kd_rk: dataItem.kd_rk,
        no_sppa: dataItem.no_sppa,
        no_updt: dataItem.no_updt,
    };
}