﻿$(document).ready(function () {
    btnSaveRoleForNavigation_Click('/RoleNavigation/Edit');
    btnAddNavigation_OnClick();
    initRoleNavigationGrid();
    loadNavigationDatasources();
});

