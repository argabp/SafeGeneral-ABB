﻿function dataApprovalInfo() {
    return {
        searchkeyword: $("#SearchApprovalInfoKeyword").val(),
        id_nds: dataItem.id_nds
    };
}