﻿$(document).ready(function () {
    btnSubmit_Click('#btnCreateNavigation', '/Navigation/Add');
    LoadSubNavigation(0);
});



