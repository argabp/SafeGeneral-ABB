﻿$(document).ready(function () {
    btnSaveRoleForNavigation_Click('/RoleNavigation/Add');
    btnAddNavigation_OnClick();
    initRoleNavigationGrid();
    loadNavigationDatasources();
});
